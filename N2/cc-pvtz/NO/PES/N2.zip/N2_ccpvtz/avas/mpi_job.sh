#!/bin/sh
#An example for MPI job.
#SBATCH -J avas_n2
#SBATCH -o job-%j.log
#SBATCH -e job-%j.err
#SBATCH -N 1 -n 40
#SBATCH -p zyli
echo Time is `date`
echo Directory is $PWD
echo This job runs on the following nodes:
echo $SLURM_JOB_NODELIST
echo This job has allocated $SLURM_JOB_CPUS_PER_NODE cpu cores.
#module load intelmpi/2018.update4
#module load intelmpi/2019.update5
#module load intel/2019.update5
#module unload intelmpi/2020
#module unload intelmpi/2019.update5
#module unload hpcx/hpcx-intel-2019.update5

#module load hpcx/hpcx-intel-2019.update5
#module load mpich/3.2/intel/2016.3.210
#module load openmpi/4.0.2/gcc/4.8.5
#module load openmpi/3.0.5/gcc/9.2.0
#module load gcc/9.2.0
#module unload vasp/5.4.4/vtst/hpcx-intel-2019.update5
#module load vasp/5.4.4/vtst/hpcx-intel-2019.update5
#module unload vasp/5.4.4/hpcx-intel-2019.update5-novtst

MPIRUN=mpirun #Intel mpi and Open MPI
#MPIRUN=mpiexec #MPICH
#MPIOPT="-env I_MPI_FABRICS shm:ofi" #Intel MPI 2018 ofa, 2019 and 2020 ofi
#MPIOPT="--mca btl self,sm,openib --mca btl_openib_cpc_include rdmacm --mca btl_openib_if_include mlx5_0:1" #Open MPI
#MPIOPT="-iface ib0" #MPICH3
#MPIOPT=
#$MPIRUN $MPIOPT ./mpiring

python main.py
